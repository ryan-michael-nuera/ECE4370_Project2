// dllmain.cpp : Defines the entry point for the DLL application.
#ifdef _WIN32
// Windows Header Files
#include <windows.h>
#endif

#include "graph.h"
#include "graph.cpp"
#include "maxflow.cpp"
#include <stdio.h>

#ifdef _WIN32
#define EXPORTIT extern "C" __declspec( dllexport )

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}
#else
#define EXPORTIT extern "C"
#endif

class ClassMap {
public:
	char cls;
};
class EdgeCost {
public:
	float n[2];
	float t[3];
};
Graph<float, float, float>* GraphCut_Iter1(int* dim, EdgeCost* s, ClassMap* si);
void GraphCut_Update(int* dim, EdgeCost* s, ClassMap* si, Graph<float, float, float>* gd, int* changenodes, int numchangednodes);

EXPORTIT void* Iter1(int* dim, EdgeCost * s, ClassMap * si) {
	return (void*)GraphCut_Iter1(dim, s, si);
}
EXPORTIT void Update(int* dim, EdgeCost * s, ClassMap * si, Graph<float, float, float>*gd, int* changenodes, int numchangednodes) {
	GraphCut_Update(dim, s, si, gd, changenodes, numchangednodes);
}
EXPORTIT void Delete(Graph<float, float, float>*g) {
	delete g;
}

void GraphCut_Update(int *dim, EdgeCost* s, ClassMap* si, Graph<float, float, float>*gd, int* changenodes, int numchangednodes) {
	//int* dim = (int*)mxGetData(prhs[0]);
	int dimxyz = dim[0] * dim[1] * dim[2];
	//double* gd = mxGetPr(prhs[3]);
	Graph<float, float, float>* g = gd;
	//EdgeCost* s = (EdgeCost*)mxGetData(prhs[1]);
	//ClassMap* si = (ClassMap*)mxGetData(prhs[2]);

	//int* changenodes = (int*)mxGetData(prhs[4]);
	//int numchangednodes = *((int*)mxGetData(prhs[5]));
	Block<Graph<float, float, float>::node_id> b(numchangednodes);
	Graph<float, float, float>::node_id* chglist = b.New(numchangednodes);
	memcpy(chglist, changenodes, sizeof(int) * numchangednodes);
	for (int i = 0; i < numchangednodes; i++) {
		g->mark_node(chglist[i]);
		float curcap = g->get_trcap(chglist[i]);
		if (si[changenodes[i]].cls == 1) {
			g->add_tweights(changenodes[i], 7, 0);
		}
		else if (si[changenodes[i]].cls == 2) {
			g->add_tweights(changenodes[i], 0, 7);
		}
	}

	double flow = g->maxflow(true, &b);
	//plhs[0] = mxDuplicateArray(prhs[2]);

	//ClassMap* seg = (ClassMap*)mxGetPr(plhs[0]);
	//plhs[1] = mxCreateDoubleMatrix(1, 1, mxREAL);
	//plhs[2] = mxCreateDoubleMatrix(1, 1, mxREAL);
	//double* o2 = mxGetPr(plhs[1]);
	//o2[0] = flow;
	//double* o3 = mxGetPr(plhs[2]);
	//double* gptr = (double*)&g;
	//o3[0] = gptr[0];

	for (int i = 0; i < dimxyz; i++) {
		if (g->what_segment(i, Graph<float, float, float>::SOURCE) == Graph<float, float, float>::SINK) si[i].cls = 2;
		else if (g->what_segment(i, Graph<float, float, float>::SINK) == Graph<float, float, float>::SOURCE) si[i].cls = 1;
		else si[i].cls = 0;
	}

	return;
}
Graph<float, float, float>* GraphCut_Iter1(int *dim, EdgeCost* s, ClassMap* si) {
	//int* dim = (int*)mxGetData(prhs[0]);
	int dimxyz = dim[0] * dim[1] * dim[2];
	Graph<float, float, float>* g = new Graph<float, float, float>(dimxyz, dimxyz * 3);
	Graph<float, float, float>::node_id n1 = g->add_node(dimxyz);
	//EdgeCost* s = (EdgeCost*)mxGetData(prhs[1]);
	//ClassMap* si = (ClassMap*)mxGetData(prhs[2]);

	printf("\nAdding n-link edges. Graph dim = %d %d %d", dim[0], dim[1], dim[2]);
	float v, maxv, K;
	int l, m, dimxy = dim[0] * dim[1];
	maxv = 0; l = 0;
	for (int i = 0; i < dim[0]; i++) for (int j = 0; j < dim[1]; j++) for (int k = 0; k < dim[2]; k++) {
		l = i + j * dim[0] + k * dimxy;
		if (i < dim[0] - 1) {
			v = s[l].t[0];
			if (v > maxv) maxv = v;
			g->add_edge(l, l + 1, v, v);
		}
		if (j < dim[1] - 1) {
			v = s[l].t[1];
			if (v > maxv) maxv = v;
			g->add_edge(l, l + dim[0], v, v);
		}
		if (k < dim[2] - 1) {
			v = s[l].t[2];
			g->add_edge(l, l + dimxy, v, v);
			if (v > maxv) maxv = v;
		}
	}
	
	K = 6 * maxv + 1;
	printf("\nAdding t-links, K=%f, dimxyz=%d",K, dimxyz);
	for (l = 0; l < dimxyz; l++) {
		if (si[l].cls == 0) {
			g->add_tweights(l, s[l].n[0], s[l].n[1]);
		}
		else if (si[l].cls == 1) {
			g->add_tweights(l, K, 0);
		}
		else if (si[l].cls == 2) {
			g->add_tweights(l, 0, K);
		}
	}

	printf("\nFinding max flow");
	double flow = g->maxflow(false);
	//plhs[0] = mxDuplicateArray(prhs[2]);

	//ClassMap* seg = (ClassMap*)mxGetPr(plhs[0]);
	//plhs[1] = mxCreateDoubleMatrix(1, 1, mxREAL);
	//plhs[2] = mxCreateDoubleMatrix(1, 1, mxREAL);
	//double* o2 = mxGetPr(plhs[1]);
	//o2[0] = flow;

	printf("\nclassifying nodes");
	for (int i = 0; i < dimxyz; i++) {
		if (g->what_segment(i, Graph<float, float, float>::SOURCE) == Graph<float, float, float>::SINK) si[i].cls = 2;
		else si[i].cls = 1;
	}

	return g;
}
